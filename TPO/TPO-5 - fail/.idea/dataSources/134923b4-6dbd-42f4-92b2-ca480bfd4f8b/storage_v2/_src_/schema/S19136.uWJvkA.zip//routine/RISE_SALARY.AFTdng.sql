create PROCEDURE rise_salary
AS
    CURSOR ma IS
    SELECT empno from BEMP where job='ANALYST' OR job='MANAGER';
    D NUMBER;
BEGIN
    OPEN ma;
    LOOP
        FETCH ma INTO D;
        EXIT WHEN ma%NOTFOUND;
        UPDATE BEMP SET sal=sal*1.1 WHERE empno=D AND job='ANALYST';
        UPDATE BEMP SET sal=sal*1.2 WHERE empno=D AND job='MANAGER';
    END LOOP;
    COMMIT;
    CLOSE ma;
END;
/

