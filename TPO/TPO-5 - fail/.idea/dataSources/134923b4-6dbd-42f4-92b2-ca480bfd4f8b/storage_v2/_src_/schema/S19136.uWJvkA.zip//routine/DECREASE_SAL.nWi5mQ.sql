create PROCEDURE decrease_sal(mgrno NUMBER)
AS 
    CURSOR subs is
    SELECT empno FROM XEMP WHERE mgr=mgrno;
    subno NUMBER;
    EVEN_LOWER_SAL EXCEPTION;
    NO_SUCH_MGR EXCEPTION;
    NO_SUBS EXCEPTION;
    low_pays NUMBER;
    mgrs NUMBER;
    subscount NUMBER;
BEGIN
    select count(empno) into low_pays from XEMP where sal<=100;
    select count(empno) into mgrs from XEMP where empno=mgrno;
    select count(empno) into subscount from XEMP where mgr=mgrno;
    IF low_pays>0 THEN RAISE EVEN_LOWER_SAL;
    END IF;
    IF mgrs=0 THEN RAISE NO_SUCH_MGR;
    END IF;
    IF subscount=0 THEN RAISE NO_SUBS;
    END IF;
    OPEN subs;
    LOOP
        FETCH subs INTO subno;
        EXIT WHEN subs%NOTFOUND;
        UPDATE XEMP SET sal=sal-100 WHERE empno=subno;
    END LOOP;
    COMMIT;
    CLOSE subs;
EXCEPTION
    WHEN EVEN_LOWER_SAL THEN DBMS_OUTPUT.PUT_LINE('EVEN_LOWER_SAL');
    WHEN NO_SUCH_MGR THEN DBMS_OUTPUT.PUT_LINE('NO_SUCH_MGR');
    WHEN NO_SUBS THEN DBMS_OUTPUT.PUT_LINE('NO_SUBS');
END;
/

