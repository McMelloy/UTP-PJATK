create PROCEDURE CancelOrder (
Ord integer)
AS
    CURSOR prod_list IS
    SELECT IdProduct, quantityOrdered
    From OrderDetails
    Where IdOrder = Ord;
    prod_fetch prod_list%ROWTYPE;
    ALREADY_CANCELLED Exception;
    stat varchar2(20);
    ORDER_DOESNT_EXIST Exception;
    c integer;
Begin
    Select count(IdOrder) into c from "Order" Where IdOrder = Ord;
    if c=0 then raise ORDER_DOESNT_EXIST;
    end if;

    Select Status into stat from "Order" Where IdOrder = Ord;
    If stat like 'cancelled' then raise ALREADY_CANCELLED;
    end if;

    OPEN prod_list;
    LOOP
        FETCH prod_list INTO prod_fetch;
        EXIT WHEN prod_list%NOTFOUND;
        UPDATE Product Set quantityInStock = quantityInStock + prod_fetch.quantityOrdered
        WHERE IdProduct = prod_fetch.IdProduct;
    END LOOP;
    COMMIT;
    CLOSE prod_list;
    UPDATE "Order" set Status = 'cancelled' WHERE IdOrder = Ord;
EXCEPTION
    WHEN ORDER_DOESNT_EXIST THEN raise_application_error(-20050,'There is no such order');
    WHEN ALREADY_CANCELLED THEN raise_application_error(-20050,'This order is already cancelled');
END;
/

