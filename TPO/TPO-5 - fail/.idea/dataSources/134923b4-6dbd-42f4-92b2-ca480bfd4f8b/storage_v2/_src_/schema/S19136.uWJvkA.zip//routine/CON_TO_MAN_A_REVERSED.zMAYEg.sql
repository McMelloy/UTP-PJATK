create PROCEDURE con_to_man_a_reversed
AS
    CURSOR consultants IS
    SELECT empno from BEMP where job='MANAGER';
    D NUMBER;
BEGIN
    OPEN consultants;
    LOOP
        FETCH consultants INTO D;
        EXIT WHEN consultants%NOTFOUND;
        UPDATE BEMP SET job='CONSULT' WHERE empno=D;
    END LOOP;
    COMMIT;
    CLOSE consultants;
END;
/

