create PROCEDURE incomsum(dep NUMBER)
AS
    salaries NUMBER;
    needed_dep NUMBER;
    people_in_dep NUMBER;
    No_such_dep EXCEPTION;
    Nobody_works EXCEPTION;
BEGIN
    SELECT count(deptno) into needed_dep FROM BDEPT WHERE deptno=dep;
    SELECT count(empno) into people_in_dep FROM BEMP WHERE deptno=dep;
    IF
        needed_dep = 0 THEN RAISE No_such_dep;
    END IF;
    IF
        people_in_dep = 0 AND needed_dep != 0 THEN RAISE Nobody_works;
    END IF;
    SELECT sum(sal) INTO salaries from BEMP WHERE deptno=dep;
    DBMS_OUTPUT.PUT_LINE('In department '||dep||' sum of salaries is '||salaries);
EXCEPTION
    WHEN Nobody_works THEN DBMS_OUTPUT.PUT_LINE('Nobody works - IT IS RAAAAAAAW');
    WHEN No_such_dep THEN DBMS_OUTPUT.PUT_LINE('No such dept - IT IS RAAAAAAAW');
END;
/

