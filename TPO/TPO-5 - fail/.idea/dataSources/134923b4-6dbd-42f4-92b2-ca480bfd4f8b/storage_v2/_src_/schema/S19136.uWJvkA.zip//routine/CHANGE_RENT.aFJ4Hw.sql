create PROCEDURE change_rent(diff integer)
AS 
    CURSOR rent_list is
    SELECT IdBranch FROM brnch;
    rent_choice integer;
    NEGATIVE_RENT EXCEPTION;
    minrent integer;
    c integer;
BEGIN
    select min(Rent) into minrent from brnch;
    IF minrent+diff<0 THEN RAISE NEGATIVE_RENT;
    END IF;
    OPEN rent_list;
    LOOP
        FETCH rent_list INTO rent_choice;
        EXIT WHEN rent_list%NOTFOUND;
        UPDATE brnch SET Rent=Rent+diff WHERE IdBranch=rent_choice;
    END LOOP;
    COMMIT;
    CLOSE rent_list;
EXCEPTION
    WHEN NEGATIVE_RENT THEN DBMS_OUTPUT.PUT_LINE('In some branch the rent will be negative');
END;
/

