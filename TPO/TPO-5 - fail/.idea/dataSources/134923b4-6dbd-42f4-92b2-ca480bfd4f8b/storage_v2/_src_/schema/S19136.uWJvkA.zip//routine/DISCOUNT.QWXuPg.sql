create PROCEDURE discount (
Idline integer,
discountAmount integer)
AS
    CURSOR prod_list IS
    SELECT IdProduct
    From Product
    Where idProductLine = Idline;
    prod_fetch integer;
    NO_LINE Exception;
    c integer;
Begin
    Select count(idProductLine) into c from ProductLine Where idProductLine = Idline;
    if c=0 then raise NO_LINE;
    end if;

    OPEN prod_list;
    LOOP
        FETCH prod_list INTO prod_fetch;
        EXIT WHEN prod_list%NOTFOUND;
        UPDATE Product SET Price = Price - discountAmount WHERE IdProduct = prod_fetch;
    END LOOP;
    COMMIT;
    CLOSE prod_list;
EXCEPTION
    WHEN NO_LINE THEN raise_application_error(-20050,'There is no such line');
END;
/

