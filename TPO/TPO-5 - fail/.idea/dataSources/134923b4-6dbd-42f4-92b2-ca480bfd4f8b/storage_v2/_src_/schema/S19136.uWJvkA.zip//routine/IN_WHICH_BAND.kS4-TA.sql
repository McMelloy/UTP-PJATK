create procedure in_which_band(MName Varchar2,MSurname Varchar2)
as
    Cursor band_list is
    Select IdBand, Band.Name from band, member, musician
    where IdBand=Band and IdMusician=Musician and Musician.name=MName and Surname=MSurname;
    choice_band band_list%ROWTYPE;
    NO_SUCH_MAN exception;
    c integer;
begin
    select count(IdMusician) into c from musician where Name=MName and Surname=MSurname;
    if c=0 then raise NO_SUCH_MAN;
    end if;
    DBMS_OUTPUT.PUT_LINE(MName||' '||MSurname||' is in following bands:');
    OPEN band_list;
    LOOP
        FETCH band_list INTO choice_band;
        EXIT WHEN band_list%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(choice_band.Name);
    END LOOP;
    CLOSE band_list;
exception
    when NO_SUCH_MAN then DBMS_OUTPUT.PUT_LINE('No such musician');
end;
/

