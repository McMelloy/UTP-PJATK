create PROCEDURE listCustomers (
city varchar2)
AS
    CURSOR cust_list IS
    SELECT FName, LName, username
    From Customer
    Where address like city;
    cust_fetch cust_list%ROWTYPE;
    NO_CUSTOMERS Exception;
    c integer;
Begin
    Select count(username) into c from Customer Where address like city;
    if c=0 then raise NO_CUSTOMERS;
    end if;

    OPEN cust_list;
    LOOP
        FETCH cust_list INTO cust_fetch;
        EXIT WHEN cust_list%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(cust_fetch.FName||' '||cust_fetch.LName||' - '||cust_fetch.username);
    END LOOP;
    COMMIT;
    CLOSE cust_list;
EXCEPTION
    WHEN NO_CUSTOMERS THEN raise_application_error(-20050,'Nobody lives in this city');
END;
/

