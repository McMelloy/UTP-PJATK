create PROCEDURE con_to_man_a
AS
    CURSOR consultants IS
    SELECT empno from BEMP where job='CONSULT';
    D NUMBER;
    people_in_job NUMBER;
    no_such_job EXCEPTION;
BEGIN
    SELECT count(empno) into people_in_job FROM BEMP WHERE job='CONSULT';
    IF
        people_in_job = 0 THEN RAISE no_such_job;
    END IF;
    OPEN consultants;
    LOOP
        FETCH consultants INTO D;
        EXIT WHEN consultants%NOTFOUND;
        UPDATE BEMP SET job='MANAGER' WHERE empno=D;
    END LOOP;
    COMMIT;
    CLOSE consultants;
EXCEPTION
    WHEN no_such_job THEN DBMS_OUTPUT.PUT_LINE('no_such_job - AND JUST SEASON IT A LITTLE BIT');
END;
/

