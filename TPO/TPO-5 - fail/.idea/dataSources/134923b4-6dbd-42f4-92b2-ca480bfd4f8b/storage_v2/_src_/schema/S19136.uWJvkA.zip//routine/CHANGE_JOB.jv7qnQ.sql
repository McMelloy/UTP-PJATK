create PROCEDURE change_job(to_be_replaced VARCHAR2,to_replace VARCHAR2)
AS
    CURSOR to_change IS
    SELECT empno from BEMP where job=to_be_replaced;
    D NUMBER;
    people_in_job NUMBER;
    no_such_job EXCEPTION;
BEGIN
    SELECT count(empno) into people_in_job FROM BEMP WHERE job=to_be_replaced;
    IF
        people_in_job = 0 THEN RAISE no_such_job;
    END IF;
    OPEN to_change;
    LOOP
        FETCH to_change INTO D;
        EXIT WHEN to_change%NOTFOUND;
        UPDATE BEMP SET job=to_replace WHERE empno=D;
    END LOOP;
    COMMIT;
    CLOSE to_change;
EXCEPTION
    WHEN no_such_job THEN DBMS_OUTPUT.PUT_LINE('no_such_job - AND JUST SEASON IT A LITTLE BIT');
END;
/

