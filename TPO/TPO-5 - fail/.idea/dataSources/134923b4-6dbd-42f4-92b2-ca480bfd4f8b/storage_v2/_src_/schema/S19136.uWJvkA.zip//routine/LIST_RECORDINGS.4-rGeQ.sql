create PROCEDURE list_recordings(d_from DATE, d_to DATE)
AS
    CURSOR rec_list IS
    SELECT IdRecording, RecDate, RecName, Name
    From Recording, Project
    Where RecDate between d_from and d_to
    and Recording.IdProject=Project.IdProject;
    rec_choice rec_list%ROWTYPE;
    NO_REC Exception;
    REVERSED_DATES Exception;
    c integer;
Begin
    if d_to<d_from then raise REVERSED_DATES;
    end if;
    Select count(IdRecording) into c from Recording Where RecDate between d_from and d_to;
    if c=0 then raise NO_REC;
    end if;
    OPEN rec_list;
    LOOP
        FETCH rec_list INTO rec_choice;
        EXIT WHEN rec_list%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(rec_choice.RecName||' of project '||rec_choice.Name||' on '||rec_choice.RecDate);
    END LOOP;
    COMMIT;
    CLOSE rec_list;
EXCEPTION
    WHEN NO_REC THEN DBMS_OUTPUT.PUT_LINE('Between those dates there are no records');
    WHEN REVERSED_DATES THEN DBMS_OUTPUT.PUT_LINE('Change the order of dates');
END;
/

