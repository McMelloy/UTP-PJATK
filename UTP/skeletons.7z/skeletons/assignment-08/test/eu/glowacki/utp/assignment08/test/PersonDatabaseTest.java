package eu.glowacki.utp.assignment08.test;
import org.junit.Test;

public class PersonDatabaseTest {

	@Test
	public void serializeAndDeserialize() {	
	}
}