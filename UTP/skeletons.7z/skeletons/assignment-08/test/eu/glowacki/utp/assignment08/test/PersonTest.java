package eu.glowacki.utp.assignment08.test;

import org.junit.Test;

public class PersonTest {

	@Test
	public void serializeAndDeserialize() {
	}
}