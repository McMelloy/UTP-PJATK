package eu.glowacki.utp.assignment02.employee;

public class Worker extends Employee {

	// attributes
	// * employment date
	// * bonus
	
	public Worker(String firstName) {
		super(firstName);
	}
}