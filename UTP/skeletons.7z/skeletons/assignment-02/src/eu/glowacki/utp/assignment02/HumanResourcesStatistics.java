package eu.glowacki.utp.assignment02;

import java.math.BigDecimal;
import java.util.List;

import eu.glowacki.utp.assignment02.employee.Employee;
import eu.glowacki.utp.assignment02.employee.Manager;
import eu.glowacki.utp.assignment02.payroll.PayrollEntry;

public final class HumanResourcesStatistics {

	public static List<PayrollEntry> payroll(List<Employee> employees) {
		return null;
	}

	public static List<PayrollEntry> subordinatesPayroll(Manager manager) {
		return null;
	}

	public static BigDecimal bonusTotal(List<Employee> employees) {
		return null;
	}

	/// ...
	// rest of the methods specified in the assignment description
}