package eu.glowacki.utp.assignment02.employee;

public class Trainee extends Employee {

	// attributes:
	// * practice start date
	// * practice length (in days)
	
	public Trainee(String firstName) {
		super(firstName);
	}
}