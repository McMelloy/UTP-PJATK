package eu.glowacki.utp.assignment10;

public final class UnimplementedException extends RuntimeException {

	private static final long serialVersionUID = -9136633471042484748L;
}