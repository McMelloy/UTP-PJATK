package eu.glowacki.utp.assignment04.test;

public final class InputParserTest {

}