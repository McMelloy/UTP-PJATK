package eu.glowacki.utp.assignment04;

import java.util.Date;
import java.util.List;

public final class PersonDatabase {

	public List<Person> sortedByFirstName() {
		return null;
	}
	
	public List<Person> sortedBySurnameFirstNameAndBirthdate() {
		return null;
	}
	
	public List<Person> sortedByBirthdate() {
		return null;
	}
	
	public List<Person> bornOnDay(Date date) {
		return null;
	}
}