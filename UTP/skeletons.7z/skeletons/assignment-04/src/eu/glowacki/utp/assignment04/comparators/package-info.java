/**
 * 
 */
/**
 * @author edek
 *
 */
package eu.glowacki.utp.assignment04.comparators;