package eu.glowacki.utp.assignment03.employee;

public class Worker extends Employee {

	// (assignment 02)
	// attributes:
	// * employment date
	// * bonus
	
	// (assignment 03)
	// attributes:
	// * has bonus
	//
	// methods:
	// * seniority is longer than given number of years (seniority - sta�)
	// * seniority is longer than given number of months
	// * has bonus greater than given amount of money
}