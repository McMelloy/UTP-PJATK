package eu.glowacki.utp.assignment03.employee;

public class Manager extends Employee {
	
	// (assignment 02)
	// attributes:
	// * subordinates (a list of immediate subordinates)
	// * all subordinates (a list of subordinates in all hierarchy)
}