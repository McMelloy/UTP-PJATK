/**
 * 
 */
/**
 * @author edek
 *
 */
package eu.glowacki.utp.assignment03.employee;