package eu.glowacki.utp.assignment03.employee;

public class Trainee extends Employee {

	// (assignment 02)
	// attributes:
	// * practice start date
	// * practice length (in days)
	
	// (assignment 03)
	// * practice length is shorter than given number of days
	// * practice length is longer than given number of days
}