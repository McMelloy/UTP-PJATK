package eu.glowacki.utp.assigment03.test;

public final class HumanResourceStatisticsTest {

}